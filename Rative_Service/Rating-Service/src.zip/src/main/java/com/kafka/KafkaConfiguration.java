package com.kafka;

import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

import com.ratingrervice.BookHoteEvent;

@Configuration
public class KafkaConfiguration{
	@KafkaListener(topics =AppConstants.HOTEL_BOOKED_TOPIC, groupId=AppConstants.GROUP_ID)
    public void handleHotelBookEvent(String bookHoteEvent) {
        // Process the order placed event and update inventory
		//String key = bookHoteEvent.key();
		//BookHoteEvent message = bookHoteEvent.value();

        // Your business logic based on the received message
        System.out.println("Received message :"+bookHoteEvent);
    }
}
