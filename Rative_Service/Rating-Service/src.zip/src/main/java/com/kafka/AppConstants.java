package com.kafka;

public class AppConstants {
	public static final String HOTEL_BOOKED_TOPIC="hotel-booked-topic";
	public static final String GROUP_ID="group-1";
}
