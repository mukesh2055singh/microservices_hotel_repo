package com.ratingrervice;

import java.io.Serializable;

public class BookHoteEvent implements Serializable {
	private int hotelId;
	
	public BookHoteEvent(int hotelId) {
		this.hotelId = hotelId;
	}
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
}
