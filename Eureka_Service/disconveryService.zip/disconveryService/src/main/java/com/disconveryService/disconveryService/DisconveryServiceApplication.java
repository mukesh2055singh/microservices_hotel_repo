package com.disconveryService.disconveryService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisconveryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisconveryServiceApplication.class, args);
	}

}
