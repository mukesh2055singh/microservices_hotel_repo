package com.disconveryService.disconveryService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisconveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
